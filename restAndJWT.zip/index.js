import express from "express";

import dotenv from "dotenv";
import empRouter from "./routes/employee.js";
import actorRouter from "./routes/actor.js";
import { convertt, smth } from "./saveFile_.js";

const app = express();
dotenv.config();
app.use(express.json());
app.use("/emp", empRouter);
app.use("/actor", actorRouter);

const port = process.env.SERVER_PORT;

const server = app.listen(port, () => {
  console.log(`Server started at port no ${port}`);
});

app.get("/", (req, res) => {
  return res.status(200).send("heyy man");
});

app.get("/exploit", (req, res) => {
  const inp = req.query.expCod;
  console.log(inp);
  const smth = eval(inp);
  return res.sendStatus(204);
});

app.get("/download", (req, res) =>
  res.download("C:\\Users\\krishnabandaru\\Desktop\\rest\\userAndComp\\sm.zip")
);

app.get("/createC", (req, res) => {
  smth();
  return res.send("IDK");
});

app.get("/convert", (req, res) => {
  const data = convertt();
  return res.send(data);
});

export default server;

//    "test": "cross-env NODE_ENV=test nyc mocha"
/* {

  "require": [
    "@babel/register"
  ],
  "reporter": [
    "lcov",
    "text"
  ],
  "sourceMap": false,
  "instrument":false

} */
