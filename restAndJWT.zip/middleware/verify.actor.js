import { getActorByEmail } from "../services/actor.js";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

const secretKey = process.env.SECRET_KEY;

const authenticateActor = async (req, res) => {
  const actor = await getActorByEmail(req.body.email);

  if (actor == null || actor == undefined)
    return res.status(404).send("User not found");

  if (actor.password != req.body.password)
    return res.status(400).send("Invalid creds");

  const accessToken = jwt.sign({ email: req.body.email }, secretKey);

  return res.status(200).send({
    accessToken: accessToken,
  });
};

const authorizeEmp = (req, res, next) => {
  const token = req.headers.authorization;

  try {
    const verifi =jwt.verify(token, secretKey);
    console.log(verifi); 
    if (verifi){
      next();
    } 
  }
  catch(err){

    console.log(err)
  }
}

export { authenticateActor, authorizeEmp };
