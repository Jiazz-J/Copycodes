import empModel from "../models/Employee.js";

const saveEmp = async (data) => {
  const emp = await empModel.create({
    name: data.name,
    empId: data.empId,
    location: data.location,
    company: data.company,
  });

  return emp;
};

const getEmpById = async (userId) => {
  if (userId == undefined) return;
  return await empModel.findByPk(userId);
};

const deleteEmpById = async (userId) => {
  return await empModel.destroy({
    where: {
      id: userId,
    },
  });
};

const getAllEmp = async () => {
  return await empModel.findAll();
};

const getEmpByName = async (findTerm) => {
  if (findTerm == undefined) return;
  return await empModel.findAll({
    where: {
      name: findTerm,
    },
  });
};

export { saveEmp, getEmpById, deleteEmpById, getAllEmp, getEmpByName };
