import companyModel from "./Company.js";
import empModel from "./Employee";


companyModel.hasMany(empModel)

empModel.hasOne(companyModel)