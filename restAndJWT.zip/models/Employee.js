import DataType from "sequelize";
import sequelize from "../config/db.pg.config.js";
import companyModel from "./Company.js";

const empModel = sequelize.define(
  "Employee",
  {
    name: {
      type: DataType.STRING,
      allowNull: false,
    },
    empId: {
      type: DataType.STRING,
      allowNull: false,
    },
    location: {
      type: DataType.STRING,
      allowNull: false,
    },
  },
  { timestamps: false, alter: true }
);

empModel.hasOne(companyModel);

export default empModel;
