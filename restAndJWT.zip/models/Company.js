import DataType from "sequelize";
import sequelize from "../config/db.pg.config.js";

const companyModel = sequelize.define(
  "Company",
  {
    name: DataType.STRING,
    location: DataType.STRING,
  },
  {
    timestamps: false,
    alter: true,
  }
);


export default companyModel;
