import fs from "fs";

const smth = () => {
  /*  var data = fs.readFileSync(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\userAndComp\\sm.zip"
  );

  console.log("buffff called ------");
  console.log(data);
  console.log("buffff called ------");

  fs.writeFile(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\seleb_co.txt",
    data,
    function (err) {
      if (err) throw "error writing file: " + err;
    }
  ); */

  var data2 = fs.readFileSync(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\dd.txt"
  );

  fs.writeFile(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\seleb_copy_3.zip",
    data2,
    function (err) {
      if (err) throw "error writing file: " + err;
    }
  );
};

const convertt = () => {
  var data = fs.readFileSync(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\userAndComp\\sm.zip"
  );
  fs.writeFile(
    "C:\\Users\\krishnabandaru\\Desktop\\rest\\seleb_co2.txt",
    data,
    function (err) {
      if (err) throw "error writing file: " + err;
    }
  );
  return data;
};

export { smth, convertt };
